Ted Lee		tlee144
Thomas Mazumder tmazumd1

For milestone 1, we have made a Makefile and skeleton main.cpp.

For milestone 2, for the majority of the time we worked on the assignment, we met together through Zoom, usually taking turns sharing screen and coding. We worked together except for implementing certain helper functions (Thomas worked on getting the index bits and file I/O, while Ted implemented the basic cache, for example), and we went off of the previous progress.
