Ted Lee tlee144
Thomas Mazumder tmazumd1

For milestone 1, we have made a makefile and skeleton main.cpp
